</html>
<head>
<meta charset="utf-8" />
<title>Nyekrip - Membuat Menu Dropdown</title>

<link href="style.css" rel="stylesheet" />

</head>
<body>
<div id="wrapper">

</div>

<div id="mid_index">

	<p align="center"><img src="gambar perumahan/a.png" width="400" height="100"></p>
	<p align="center"><font face="Comic Sans MS" size="3" color="#000000">Alamat :Perumahan Kaweoron-Talun-Biltar-JawaTimur</p>
	<nav>
	<ul>
		<li><a href="beranda.php"><font  face="Comic Sans MS" color=" #000000" size="3">Beranda</a></li>
		<li><a href="about.php"><font  face="Comic Sans MS" color=" #000000" size="3">Tentang</a></li>
		<li><a href="schedule.php"><font  face="Comic Sans MS" color=" #000000" size="3">Jadwal Kegiatan Warga</a></li>
		<li><a href="event.php"><font  face="Comic Sans MS" color=" #000000" size="3">Acara</a></li>
		<li><a href="album.php"><font  face="Comic Sans MS" color=" #000000" size="3">Album</a></li>
		<li><a href="store.php"><font  face="Comic Sans MS" color=" #000000" size="3">Toko</a></li>
		<li><a href="contact.php"><font  face="Comic Sans MS" color=" #000000" size="3">Kontak</a></li>
	</ul>
	</nav>
	<p align="center"><font face="Comic Sans MS" size="5" color="#B8860B"/>Produk Produk Alfamart</p>
<table border="1" align="center" >
			<tr>
			<td colspan="5" align="center"> Produk 1</td>
			</tr>
			
			<tr>
			<td> Sari Roti</td>
			<td> Roti Sisir</td>
			<td> Aqua</td>
			<td> Floridina</td>
			<td> Wonderland Biscuit</td>
			</tr>
			
			<tr> 
			<td><img src="gambar perumahan/p2.jpg" Width="100%" Height="160"align="center"></td>
			<td><img src="gambar perumahan/p1.jpg" Width="100%" Height="160"align="center"></td>
			<td><img src="gambar perumahan/p3.jpg" Width="100%" Height="160"align="center"></td>
			<td><img src="gambar perumahan/p4.jpg" Width="100%" Height="160"align="center"></td>
			<td><img src="gambar perumahan/p5.jpg" Width="100%" Height="160"align="center"></td>
			</tr>
			
			<tr>
			<td> Harga Rp 100.000</td>
			<td><strike>Harga Rp 100.000</strike> <br>SoldOut</br></td>
			<td> Harga Rp 100.000</td>
			<td> Harga Rp 100.000</td>
			<td><strike>Harga Rp 100.000</strike> <br>SoldOut</br></td>
			</tr>
		</table>
		<br></br>
		<table border="1" align="center" >
			<tr>
			<td colspan="5" align="center"> Produk 2</td>
			</tr>
			
			<tr>
			<td> Aurora</td>
			<td> MieKuya Ramen</td>
			<td> Richease</td>
			<td> Kacang Telur Garuda</td>
			<td> Stela Parfume Ruangan</td>
			</tr>
			
			<tr> 
			<td><img src="gambar perumahan/p6.jpg" Width="100%" Height="160"align="center"></td>
			<td><img src="gambar perumahan/p7.jpg" Width="100%" Height="160"align="center"></td>
			<td><img src="gambar perumahan/p8.jpg" Width="100%" Height="160"align="center"></td>
			<td><img src="gambar perumahan/p9.jpg" Width="100%" Height="160"align="center"></td>
			<td><img src="gambar perumahan/p10.jpg" Width="100%" Height="160"align="center"></td>
			</tr>
			
			<tr>
			<td> Harga Rp 100.000</td>
			<td> Harga Rp 100.000</td>
			<td> Harga Rp 100.000</td>
			<td> Harga Rp 100.000</td>
			<td> Harga Rp 100.000 </td>
			</tr>		
		</table>
		<br></br>
		<table border="1" align="center" >
			<tr>
			<td colspan="5" align="center"> Produk 3</td>
			</tr>
			
			<tr>
			<td> Beras Bengawan </td>
			<td> Taro</td>
			<td> Tisu Basah Alfamart</td>
			<td> Mie Sedap</td>
			<td> Sabun Lifeboy</td>
			</tr>
			
			<tr> 
			<td><img src="gambar perumahan/p11.jpg" Width="100%" Height="160"align="center"></td>
			<td><img src="gambar perumahan/p13.jpg" Width="100%" Height="160"align="center"></td>
			<td><img src="gambar perumahan/p14.jpg" Width="100%" Height="160"align="center"></td>
			<td><img src="gambar perumahan/p15.jpg" Width="100%" Height="160"align="center"></td>
			<td><img src="gambar perumahan/p16.jpg" Width="100%" Height="160"align="center"></td>
			</tr>
			
			<tr>
			<td> Harga Rp 100.000</td>
			<td> Harga Rp 100.000</td>
			<td> Harga Rp 100.000</td>
			<td> Harga Rp 100.000</td>
			<td> Harga Rp 100.000 </td>	
			</tr>		
		</table>	
		</table>
</div>
</body>
</html>