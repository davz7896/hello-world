</html>
<head>
<meta charset="utf-8" />
<title>Nyekrip - Membuat Menu Dropdown</title>

<link href="style.css" rel="stylesheet" />

</head>
<body>
<div id="wrapper">

</div>

<div id="mid_index">

	<p align="center"><img src="gambar perumahan/a.png" width="400" height="100"></p>
	<p align="center"><font face="Comic Sans MS" size="3" color="#000000">Alamat :Perumahan Kaweoron-Talun-Biltar-JawaTimur</p>
	<nav>
	<ul>
		<li><a href="beranda.php"><font  face="Comic Sans MS" color=" #000000" size="3">Beranda</a></li>
		<li><a href="about.php"><font  face="Comic Sans MS" color=" #000000" size="3">Tentang</a></li>
		<li><a href="schedule.php"><font  face="Comic Sans MS" color=" #000000" size="3">Jadwal Kegiatan Warga</a></li>
		<li><a href="event.php"><font  face="Comic Sans MS" color=" #000000" size="3">Acara</a></li>
		<li><a href="album.php"><font  face="Comic Sans MS" color=" #000000" size="3">Album</a></li>
		<li><a href="store.php"><font  face="Comic Sans MS" color=" #000000" size="3">Toko</a></li>
		<li><a href="contact.php"><font  face="Comic Sans MS" color=" #000000" size="3">Kontak</a></li>
	</ul>
	</nav>
	<p align="center"><font face="Comic Sans MS" size="5" color="#B8860B"/>Toko Toko Perumahan Kaweron Pondok Delta</p>
	<table border="0" bgcolor=" #F4A460" align="center" width="380" cellspacing="15" cellpadding="10">
			<tr>
			<td><p align="center">Toko Kebutuhan Pokok<p></td>
			<td><p align="center">Toko Peralatan Kerja dan Sekolah<p></td>
			</tr>
			<tr>
			<td><a href="TKP.php"><img src="gambar perumahan/alfamart3.jpg" Width="350" Height="260"align="center"></a></td>
			<td><img src="gambar perumahan/pk.jpg" Width="350" Height="260"align="center"></td>
			</tr>		
		</table>
		</br>
		</br>
		<table border="0" bgcolor=" #F4A460" align="center" width="380" cellspacing="15" cellpadding="10">
			<tr>
			<td><p align="center">Toko Mabel<p></td>
			<td><p align="center">Toko Sovenir<p></td>
			</tr>
			<tr>
			<td><img src="gambar perumahan/mabel1.jpg" Width="350" Height="260"align="center"></td>
			<td><img src="gambar perumahan/sovenir4.jpg" Width="350" Height="260"align="center"></td>
			</tr>		
		</table>
</div>

</body>
</html>