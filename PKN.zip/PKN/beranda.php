</html>
<head>
<meta charset="utf-8" />
<title>Nyekrip - Membuat Menu Dropdown</title>

<link href="style.css" rel="stylesheet" />

</head>
<body>
<div id="wrapper">

</div>
<div id="header">
<table border="0" align="center"cellpadding="0" cellspacing="0">
			<tr>
			<td><p align="justify"><img src="gambar perumahan/perum1.jpg" Width="327" Height="220"align="left"><p></td>
			<td><p align="justify"><img src="gambar perumahan/perum2.jpg" Width="327" Height="220"align="left"><p></td>
			<td><p align="justify"><img src="gambar perumahan/perum3.jpg" Width="327" Height="220"align="left"><p></td>
			</tr>
			
		</table>
</div>
<div id="mid_index">

	<p align="center"><img src="gambar perumahan/a.png" width="400" height="100"></p>
	<p align="center"><font face="Comic Sans MS" size="3" color="#000000">Alamat :Jalan Kaweron RT02 RW07-Talun-Biltar-JawaTimur</p>
	<nav>
	<ul>
		<li><a href="beranda.php"><font  face="Comic Sans MS" color=" #000000" size="3">Beranda</a></li>
		<li><a href="about.php"><font  face="Comic Sans MS" color=" #000000" size="3">Tentang</a></li>
		<li><a href="schedule.php"><font  face="Comic Sans MS" color=" #000000" size="3">Jadwal Kegiatan Warga</a></li>
		<li><a href="event.php"><font  face="Comic Sans MS" color=" #000000" size="3">Acara</a></li>
		<li><a href="album.php"><font  face="Comic Sans MS" color=" #000000" size="3">Album</a></li>
		<li><a href="store.php"><font  face="Comic Sans MS" color=" #000000" size="3">Toko</a></li>
		<li><a href="contact.php"><font  face="Comic Sans MS" color=" #000000" size="3">Kontak</a></li>
	</ul>
	</nav>
		<br></br>
		<table border="0" align="center">
			<tr>
			<td><p align="center"><img src="gambar perumahan/perumahan1.jpg" Width="200" Height="200"align="center"><p></td>
			<td><p align="center"><img src="gambar perumahan/perumahan2.jpg" Width="300" Height="200"align="center"><p></td>
			<td><p align="center"><img src="gambar perumahan/perumahan1	.jpg" Width="200" Height="200"align="center"><p></td>
			</tr>
			
		</table>
		
	<p align="center"><font size="2">Adalah suatu kebanggaan bagi kami bisa mempersembahkan salah satu mahakarya kami. Yaitu perumahan mewah di tengah kota Blitar, yang disebut dengan Perumahan "Kaweron Pondok Delta". Dibangun di atas lahan seluas 7,5 hektar dengan total keseluruhan sekitar 200 unit. Perumahan "Kaweron Pondok Delta" hanya menjual rumah 2 lantai saja dengan harga mulai sekitar 1,7 milyard. Dan saat ini unit rumah yang masih ada hanya 25 unit.</p>
<br></br>
<br></br>
<table border="0" align="center">
			<tr>
			<td><p align="center"><img src="gambar perumahan/perum7.jpg" Width="200" Height="200"align="center"><p></td>
			<td width="50"><td>
			<td><p align="center"><img src="gambar perumahan/perum8.jpg" Width="200" Height="200"align="center"><p></td>
			</tr>			
</table>
	<p> Cari Alamat Rumah yang anda inginkan</p>
	<p align="center"><input class="search" type="text" placeholder="Cari..." required>
	<input class="button" type="button" value="Cari"></p>	
<table border="0" align="center">
			<tr>
			<td width="75"><a href="https://www.facebook.com/"><img src="gambar perumahan/facebook.png" width="50"></a></td>
			<td><a href="https://www.instagram.com/"><img src="gambar perumahan/instagram.jpg" width="68	"></a></td>
			</tr>			
</table>

</div>

</body>
</html>